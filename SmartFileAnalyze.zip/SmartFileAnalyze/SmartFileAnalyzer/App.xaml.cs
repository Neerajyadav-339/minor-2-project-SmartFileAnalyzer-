﻿using MaterialDesignThemes.Wpf;
using Serilog;
using SmartFileAnalyzer.Data;
using System;
using System.Linq;
using System.Windows;

namespace SmartFileAnalyzer
{
    public partial class App : Application
    {
        public static bool IsDarkMode = true;
        public static bool RequireDeleteConfirmation = true;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.File("logs/analyzer-log.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();

            Log.Information("SmartFileAnalyzer Application Started.");

            using (var db = new AppDbContext())
            {
                db.Database.EnsureCreated();
                if (!db.Users.Any())
                {
                    db.Users.Add(new UserAccount { Username = "admin", Role = "Administrator", LastLogin = DateTime.Now });
                    db.SaveChanges();
                }
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            Log.Information("SmartFileAnalyzer Application Closed.");
            Log.CloseAndFlush();
            base.OnExit(e);
        }

        public static void ToggleTheme()
        {
            IsDarkMode = !IsDarkMode;
            PaletteHelper paletteHelper = new PaletteHelper();
            Theme theme = paletteHelper.GetTheme();
            theme.SetBaseTheme(IsDarkMode ? BaseTheme.Dark : BaseTheme.Light);
            paletteHelper.SetTheme(theme);
        }
    }
}