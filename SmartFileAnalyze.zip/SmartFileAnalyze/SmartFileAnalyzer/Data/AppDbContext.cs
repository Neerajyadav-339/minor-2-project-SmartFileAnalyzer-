﻿using Microsoft.EntityFrameworkCore;
using System;

namespace SmartFileAnalyzer.Data
{
    public class UserAccount
    {
        public int Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Role { get; set; } = "Standard User";
        public DateTime LastLogin { get; set; }
    }

    public class AppDbContext : DbContext
    {
        public DbSet<UserAccount> Users { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=SmartFileAnalyzer.db");
        }
    }
}