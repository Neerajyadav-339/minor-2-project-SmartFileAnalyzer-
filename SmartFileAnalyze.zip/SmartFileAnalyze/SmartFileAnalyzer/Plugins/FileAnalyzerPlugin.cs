﻿using Microsoft.SemanticKernel;
using SmartFileAnalyzer.ViewModels;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows;

namespace SmartFileAnalyzer.Plugins
{
    public class FileAnalyzerPlugin
    {
        private readonly MainViewModel _viewModel;

        public FileAnalyzerPlugin(MainViewModel viewModel)
        {
            _viewModel = viewModel;
        }

        [KernelFunction("scan_for_duplicates")]
        [Description("Scans the user's selected folder for exact and fuzzy duplicate files.")]
        public async Task ScanForDuplicatesAsync()
        {
            // FIXED: Using InvokeAsync and awaiting it to resolve CS1998
            await Application.Current.Dispatcher.InvokeAsync(() => _viewModel.TriggerFolderSelectAndScan(false));
        }

        [KernelFunction("scan_for_faces")]
        [Description("Scans the user's selected folder to extract unique human faces and cluster identities.")]
        public async Task ScanForFacesAsync()
        {
            // FIXED: Using InvokeAsync and awaiting it
            await Application.Current.Dispatcher.InvokeAsync(() => _viewModel.TriggerFolderSelectAndScan(true));
        }

        [KernelFunction("export_csv_report")]
        [Description("Exports the current scan results on the screen to a CSV file for the user.")]
        public string ExportReport()
        {
            Application.Current.Dispatcher.Invoke(() => _viewModel.ExportToCsvCommand.Execute(null));
            return "Report successfully exported to CSV.";
        }

        [KernelFunction("delete_selected_files")]
        [Description("Deletes the files that are currently flagged or selected as duplicates.")]
        public string DeleteSelected()
        {
            Application.Current.Dispatcher.Invoke(() => _viewModel.DeleteSelectedCommand.Execute(null));
            return "Selected duplicate files have been deleted.";
        }
    }
}