﻿#pragma warning disable SKEXP0070 

using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Connectors.Google; // <-- NEW: Required for API Versioning
using SmartFileAnalyzer.Plugins;
using SmartFileAnalyzer.ViewModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SmartFileAnalyzer.Services
{
    public class AIAgentManager
    {
        private Kernel? _kernel;

        // 👇 PASTE YOUR ACTUAL API KEY HERE 👇
        private readonly string _apiKey = "AIzaSyDPxYh9ag3NspJPc0Hr04BfuM142yV1uwI";

        public void InitializeAgent(MainViewModel viewModel, string modelSelection)
        {
            var builder = Kernel.CreateBuilder();

            // FIXED 1: Use the exact base model names recognized by the stable V1 endpoint
            string modelId = modelSelection.Contains("Flash") ? "gemini-1.5-flash" : "gemini-1.5-pro";

            // FIXED 2: Explicitly force the stable V1 endpoint instead of the default Beta
            builder.AddGoogleAIGeminiChatCompletion(
                modelId: modelId,
                apiKey: _apiKey,
                apiVersion: GoogleAIVersion.V1
            );

            builder.Plugins.AddFromObject(new FileAnalyzerPlugin(viewModel), "FileTools");
            _kernel = builder.Build();
        }

        public async Task<string> ProcessCommandAsync(string userPrompt)
        {
            try
            {
                if (_kernel == null) return "AI Agent is not initialized.";

                var settings = new PromptExecutionSettings
                {
                    ExtensionData = new Dictionary<string, object>()
                    {
                        { "tool_call_behavior", "AutoInvokeKernelFunctions" }
                    }
                };

                string fullPrompt = $"You are an AI assistant built into the SmartFileAnalyzer desktop app. " +
                                    $"Use your tools to help the user. If they ask you to scan or delete, call the tools. " +
                                    $"User Request: {userPrompt}";

                var result = await _kernel!.InvokePromptAsync(fullPrompt, new KernelArguments(settings));
                return result.ToString();
            }
            catch (Exception ex)
            {
                return $"Error connecting to AI: {ex.Message}";
            }
        }
    }
}