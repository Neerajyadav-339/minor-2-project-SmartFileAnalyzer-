﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using FaceRecognitionDotNet;
using MetadataExtractor;
using Microsoft.Win32;
using OpenCvSharp;
using Serilog;
using SmartFileAnalyzer.Services;
using System;
using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace SmartFileAnalyzer.ViewModels
{
    public partial class FileItemViewModel : ObservableObject
    {
        [ObservableProperty] private bool _isSelected;
        public string Path { get; set; } = "";
        public string Name { get; set; } = "";
        public string Info { get; set; } = "";
    }

    public class ChatMessage
    {
        public string Sender { get; set; } = "";
        public string Message { get; set; } = "";
        public bool IsUser => Sender == "You";
    }

    public partial class MainViewModel : ObservableObject
    {
        [ObservableProperty] private ObservableCollection<FileItemViewModel> _fileItems = new();
        [ObservableProperty] private int _scanProgress;
        [ObservableProperty] private string _progressStatus = "Ready";
        [ObservableProperty] private bool _isScanning;

        [ObservableProperty] private ObservableCollection<ChatMessage> _chatHistory = new();
        [ObservableProperty] private string _userInput = "";
        [ObservableProperty] private bool _isAiThinking;

        [ObservableProperty]
        private ObservableCollection<string> _availableModels = new()
        {
            "Gemini 1.5 Flash (Fast/Demo)",
            "Gemini 1.5 Pro (Advanced)"
        };
        [ObservableProperty] private string _selectedModel = "Gemini 1.5 Flash (Fast/Demo)";

        private AIAgentManager _aiAgent;

        partial void OnSelectedModelChanged(string value)
        {
            _aiAgent.InitializeAgent(this, value);
            ChatHistory.Add(new ChatMessage { Sender = "System", Message = $"Switched AI Engine to: {value}" });
        }

        public MainViewModel()
        {
            _aiAgent = new AIAgentManager();
            _aiAgent.InitializeAgent(this, SelectedModel);
            ChatHistory.Add(new ChatMessage { Sender = "AI Copilot", Message = "Hello! Ask me to scan a folder, find faces, or export a report." });
        }

        [RelayCommand]
        private async Task SendMessageAsync()
        {
            if (string.IsNullOrWhiteSpace(UserInput)) return;
            string messageToSend = UserInput;
            UserInput = "";
            ChatHistory.Add(new ChatMessage { Sender = "You", Message = messageToSend });

            IsAiThinking = true;
            string response = await _aiAgent.ProcessCommandAsync(messageToSend);
            ChatHistory.Add(new ChatMessage { Sender = "AI Copilot", Message = response });
            IsAiThinking = false;
        }

        public void TriggerFolderSelectAndScan(bool isFaceScan)
        {
            var dialog = new OpenFolderDialog { Title = "Select Folder to Scan" };
            if (dialog.ShowDialog() == true)
            {
                if (isFaceScan) ClusterFacesCommand.Execute(dialog.FolderName);
                else ScanFilesCommand.Execute(dialog.FolderName);
            }
        }

        [RelayCommand]
        private void DeleteSelected()
        {
            var selected = FileItems.Where(x => x.IsSelected).ToList();
            if (!selected.Any()) return;
            foreach (var file in selected)
            {
                try { File.Delete(file.Path); FileItems.Remove(file); } catch { }
            }
        }

        [RelayCommand(IncludeCancelCommand = true)]
        private async Task ScanFilesAsync(string folderPath, CancellationToken token)
        {
            IsScanning = true; FileItems.Clear(); ScanProgress = 0;
            ProgressStatus = "Scanning with Parallel Processing...";

            try
            {
                // FIXED: Explicit System.IO.Directory to remove ambiguity
                var files = System.IO.Directory.GetFiles(folderPath, "*.*", System.IO.SearchOption.AllDirectories);
                int totalFiles = files.Length;
                int processed = 0;
                var hashedFiles = new ConcurrentDictionary<string, ConcurrentBag<string>>();

                // FIXED: Removed the unnecessary "async" inside the parallel loop to stop the CS1998 warning
                await Parallel.ForEachAsync(files, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount, CancellationToken = token }, (file, ct) =>
                {
                    try
                    {
                        string hash = ComputeMD5(file);
                        hashedFiles.AddOrUpdate(hash, new ConcurrentBag<string> { file }, (key, bag) => { bag.Add(file); return bag; });
                    }
                    catch (Exception ex) { Log.Error(ex, $"Failed to process file: {file}"); }

                    int current = Interlocked.Increment(ref processed);
                    ScanProgress = (current * 100) / totalFiles;

                    return ValueTask.CompletedTask;
                });

                foreach (var group in hashedFiles.Values.Where(g => g.Count > 1))
                {
                    bool isFirst = true;
                    foreach (var file in group.OrderByDescending(f => new FileInfo(f).Length))
                    {
                        string cameraModel = GetExifCameraModel(file);
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            FileItems.Add(new FileItemViewModel
                            {
                                Path = file,
                                Name = Path.GetFileName(file),
                                Info = isFirst ? $"Original ({cameraModel})" : $"Duplicate ({cameraModel})",
                                IsSelected = !isFirst
                            });
                        });
                        isFirst = false;
                    }
                }
            }
            catch (OperationCanceledException) { ProgressStatus = "Scan Canceled."; }
            finally { IsScanning = false; GC.Collect(); }
        }

        [RelayCommand(IncludeCancelCommand = true)]
        private async Task ClusterFacesAsync(string folderPath, CancellationToken token)
        {
            IsScanning = true; FileItems.Clear(); ScanProgress = 0;
            ProgressStatus = "Extracting Unique Identities...";

            try
            {
                var files = System.IO.Directory.GetFiles(folderPath, "*.*", System.IO.SearchOption.AllDirectories).Where(f => IsImage(f)).ToList();
                int totalImages = files.Count;
                if (totalImages == 0) return;

                // FIXED: Push the heavy Dlib math to a background CPU thread so the UI doesn't freeze
                await Task.Run(() =>
                {
                    int processed = 0;
                    var knownPeople = new System.Collections.Generic.Dictionary<int, FaceEncoding>();
                    int nextPersonId = 1;

                    using var fr = FaceRecognition.Create("Models");

                    foreach (var file in files)
                    {
                        if (token.IsCancellationRequested) break;
                        string tempFile = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString() + ".jpg");
                        bool usedTempFile = false;
                        string fileToAnalyze = file;

                        try
                        {
                            using (var originalMat = Cv2.ImRead(file))
                            {
                                if (!originalMat.Empty() && originalMat.Width > 800)
                                {
                                    double scale = 800.0 / originalMat.Width;
                                    using var resizedMat = new Mat();
                                    Cv2.Resize(originalMat, resizedMat, new OpenCvSharp.Size(800, (int)(originalMat.Height * scale)));
                                    Cv2.ImWrite(tempFile, resizedMat);
                                    fileToAnalyze = tempFile; usedTempFile = true;
                                }
                            }

                            using var image = FaceRecognition.LoadImageFile(fileToAnalyze);
                            var faceLocations = fr.FaceLocations(image).ToList();

                            if (faceLocations.Count > 0)
                            {
                                var faceEncodings = fr.FaceEncodings(image, faceLocations).ToList();
                                var newlyDiscoveredIdentities = new System.Collections.Generic.List<string>();

                                foreach (var encoding in faceEncodings)
                                {
                                    bool matchFound = false;
                                    foreach (var knownPerson in knownPeople)
                                    {
                                        if (FaceRecognition.FaceDistance(knownPerson.Value, encoding) < 0.6)
                                        { matchFound = true; break; }
                                    }

                                    if (!matchFound)
                                    {
                                        knownPeople.Add(nextPersonId, encoding);
                                        newlyDiscoveredIdentities.Add($"Person {nextPersonId}");
                                        nextPersonId++;
                                    }
                                }

                                if (newlyDiscoveredIdentities.Count > 0)
                                {
                                    string identityString = string.Join(", ", newlyDiscoveredIdentities);
                                    Application.Current.Dispatcher.Invoke(() =>
                                    {
                                        FileItems.Add(new FileItemViewModel
                                        {
                                            Path = file,
                                            Name = Path.GetFileName(file),
                                            Info = $"Identity: {identityString}",
                                            IsSelected = false
                                        });
                                    });
                                }
                                foreach (var enc in faceEncodings) enc.Dispose();
                            }
                        }
                        catch { }
                        finally { if (usedTempFile && File.Exists(tempFile)) { try { File.Delete(tempFile); } catch { } } }

                        processed++;

                        // Safely update the progress bar UI from the background thread
                        Application.Current.Dispatcher.Invoke(() => ScanProgress = (processed * 100) / totalImages);
                    }
                }, token);
            }
            catch (OperationCanceledException) { ProgressStatus = "Scan Canceled."; }
            finally { IsScanning = false; GC.Collect(); }
        }

        [RelayCommand]
        private void ExportToCsv()
        {
            try
            {
                var csv = new StringBuilder();
                csv.AppendLine("FileName,Status,Path");
                foreach (var item in FileItems) csv.AppendLine($"\"{item.Name}\",\"{item.Info}\",\"{item.Path}\"");
                File.WriteAllText("ScanReport.csv", csv.ToString());
                ProgressStatus = "Report Exported to ScanReport.csv";
            }
            catch (Exception ex) { Log.Error(ex, "Failed to export CSV."); }
        }

        private string ComputeMD5(string filePath)
        {
            using var md5 = System.Security.Cryptography.MD5.Create();
            using var stream = File.OpenRead(filePath);
            return BitConverter.ToString(md5.ComputeHash(stream));
        }

        private string GetExifCameraModel(string path)
        {
            try
            {
                if (!IsImage(path)) return "N/A";
                var directories = ImageMetadataReader.ReadMetadata(path);
                var subIfdDirectory = directories.OfType<MetadataExtractor.Formats.Exif.ExifIfd0Directory>().FirstOrDefault();
                return subIfdDirectory?.GetDescription(MetadataExtractor.Formats.Exif.ExifIfd0Directory.TagModel) ?? "Unknown Camera";
            }
            catch { return "No EXIF"; }
        }

        private bool IsImage(string path)
        {
            var ext = Path.GetExtension(path).ToLower();
            return ext == ".jpg" || ext == ".png" || ext == ".jpeg";
        }
    }
}