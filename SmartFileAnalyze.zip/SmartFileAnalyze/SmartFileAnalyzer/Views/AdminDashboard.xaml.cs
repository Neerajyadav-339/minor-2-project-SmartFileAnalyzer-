﻿using SmartFileAnalyzer.Data;
using System.Linq;
using System.Windows;

namespace SmartFileAnalyzer.Views
{
    public partial class AdminDashboard : Window
    {
        public AdminDashboard()
        {
            InitializeComponent();
            using (var db = new AppDbContext())
            {
                UsersGrid.ItemsSource = db.Users.ToList();
            }
        }
        private void Logout_Click(object sender, RoutedEventArgs e) { new LoginWindow().Show(); this.Close(); }
    }
}