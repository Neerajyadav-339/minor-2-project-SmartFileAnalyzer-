﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;

// FIXED: Namespace correctly matches the Views folder to satisfy the XAML partial class
namespace SmartFileAnalyzer.Views
{
    public partial class ImagePreviewWindow : Window
    {
        public ImagePreviewWindow(string imagePath)
        {
            InitializeComponent();
            LoadImage(imagePath);
        }

        private void LoadImage(string path)
        {
            try
            {
                FileNameText.Text = Path.GetFileName(path);
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                image.UriSource = new Uri(path);
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.EndInit();
                image.Freeze();
                FullResImage.Source = image;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load image.\n\n" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e) { this.Close(); }
    }
}