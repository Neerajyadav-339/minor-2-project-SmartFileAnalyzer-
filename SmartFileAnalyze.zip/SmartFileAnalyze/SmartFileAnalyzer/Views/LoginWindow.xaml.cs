﻿using SmartFileAnalyzer.Data;
using System;
using System.Linq;
using System.Windows;

// FIXED: Namespace correctly matches the Views folder to satisfy the XAML partial class
namespace SmartFileAnalyzer.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow() { InitializeComponent(); }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new AppDbContext())
            {
                var user = db.Users.FirstOrDefault(u => u.Username.ToLower() == UsernameBox.Text.ToLower());
                if (user != null)
                {
                    user.LastLogin = DateTime.Now;
                    db.SaveChanges();
                    if (user.Role == "Administrator") new AdminDashboard().Show();
                    else new MainWindow().Show();
                    this.Close();
                }
                else { MessageBox.Show("Invalid credentials.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning); }
            }
        }

        private void CreateAccount_Click(object sender, RoutedEventArgs e) { new RegisterWindow().Show(); this.Close(); }
        private void ThemeToggle_Click(object sender, RoutedEventArgs e) { App.ToggleTheme(); }
    }
}