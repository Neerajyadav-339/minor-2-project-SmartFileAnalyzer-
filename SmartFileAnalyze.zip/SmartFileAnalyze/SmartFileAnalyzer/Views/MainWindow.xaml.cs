﻿using System.IO;
using System.Windows;
using SmartFileAnalyzer.ViewModels;

namespace SmartFileAnalyzer.Views
{
    public partial class MainWindow : Window
    {
        private MainViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            _viewModel = new MainViewModel();
            this.DataContext = _viewModel;
        }

        private void PreviewImage_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag is string imagePath && File.Exists(imagePath))
            {
                new ImagePreviewWindow(imagePath) { Owner = this }.ShowDialog();
            }
        }

        private void Settings_Click(object sender, RoutedEventArgs e) { new SettingsWindow { Owner = this }.ShowDialog(); }
        private void Logout_Click(object sender, RoutedEventArgs e) { new LoginWindow().Show(); this.Close(); }
    }
}