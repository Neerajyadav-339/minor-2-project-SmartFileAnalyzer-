﻿using SmartFileAnalyzer.Data;
using System;
using System.Linq;
using System.Windows;

namespace SmartFileAnalyzer.Views
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow() { InitializeComponent(); }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string newUsername = NewUsernameBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(newUsername)) return;

            using (var db = new AppDbContext())
            {
                if (db.Users.Any(u => u.Username.ToLower() == newUsername.ToLower()))
                {
                    MessageBox.Show("Username taken.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                db.Users.Add(new UserAccount { Username = newUsername, Role = "Standard User", LastLogin = DateTime.Now });
                db.SaveChanges();
            }
            MessageBox.Show("Account created!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            new LoginWindow().Show(); this.Close();
        }
        private void BackToLogin_Click(object sender, RoutedEventArgs e) { new LoginWindow().Show(); this.Close(); }
    }
}