﻿using System.Windows;

namespace SmartFileAnalyzer.Views
{
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            InitializeComponent();
            DarkModeCheck.IsChecked = App.IsDarkMode;
            ConfirmDeleteCheck.IsChecked = App.RequireDeleteConfirmation;
        }

        private void ThemeToggle_Click(object sender, RoutedEventArgs e) { App.ToggleTheme(); }
        private void ConfirmDelete_Click(object sender, RoutedEventArgs e) { App.RequireDeleteConfirmation = ConfirmDeleteCheck.IsChecked ?? true; }
        private void Close_Click(object sender, RoutedEventArgs e) { this.Close(); }
    }
}